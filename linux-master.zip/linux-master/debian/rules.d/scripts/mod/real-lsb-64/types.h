#include "../types.h"
typedef __u64 __attribute__((aligned(8))) kernel_ulong_t;
#define BITS_PER_LONG 64
